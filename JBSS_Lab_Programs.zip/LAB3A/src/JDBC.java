import java.sql.*;
import java.util.Scanner;

public class JDBC {
	Connection con = null;
	
	
public Connection getconnect()
{
	try
	{
	Class.forName("com.mysql.cj.jdbc.Driver");
	con = DriverManager.getConnection("jdbc:mysql://172.16.34.105:3306/1rv21mc083","1rv21mc083","1rv21mc083");
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	return con;
}
public void display(String tname)
{
	try
	{
	con = getconnect();
	Statement st = con.createStatement();
	ResultSet rs = st.executeQuery("select * from student");
	System.out.println("\n   USN        NAME       ADDRESS\n");
	while(rs.next())
	{
		System.out.println(rs.getString(1)+"   "+rs.getString(2)+"   "+rs.getString(3));
	}
	con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}

public void insert(String tname,String usn, String name, String address)
{
	try
	{
	con = getconnect();
	Statement st = con.createStatement();
	String query = "insert into "+tname+" values('"+usn+"','"+name+"','"+address+"')";
	st.executeUpdate(query);
	System.out.println("\nData Inserted Successfully\n");
	con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}

public void update(String tname,String usn, String name)
{
	try
	{
	con = getconnect();
	Statement st = con.createStatement();
	String query = "update "+tname+" set name='"+name+"' where usn='"+usn+"'";
	st.executeUpdate(query);
	System.out.println("\nData Updated Successfully\n");
	con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}

public void delete(String tname,String usn)
{
	try
	{
	con = getconnect();
	Statement st = con.createStatement();
	String query = "delete from "+tname+" where usn='"+usn+"'";
	st.executeUpdate(query);
	System.out.println("\nData Deleted Successfully\n");
	con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}


	public static void main(String[] args) {
		String tname,usn,name,address;
		JDBC jd = new JDBC();
		Scanner sc = new Scanner(System.in);
		
		while(true)
		{
			System.out.println("\n 0. Exit \n 1. Insert \n 2. Display \n 3. Update Name \n 4. Delete \n Enter Your Choice: ");
			int ch = sc.nextInt();
		
			if (ch==0) {
				System.exit(0);
			}
			
			else if(ch==2)	{
				Scanner sc2 = new Scanner(System.in);
		System.out.println("Enter Table Name: ");
		tname= sc2.nextLine();
		jd.display(tname);
			}
		
		else if(ch==1) {
			Scanner scc = new Scanner(System.in);
		System.out.println("Enter Table Name: ");
		tname= scc.nextLine();
		System.out.println("Enter USN: ");
		usn= scc.nextLine();
		System.out.println("Enter Student Name: ");
		name= scc.nextLine();
		System.out.println("Enter Address: ");
		address= scc.nextLine();
		jd.insert(tname, usn, name, address);
		}
		
		else if(ch==3) {
			Scanner s = new Scanner(System.in);
		System.out.println("Enter Table Name: ");
		tname= s.nextLine();
		System.out.println("Enter USN: ");
		usn= s.nextLine();
		System.out.println("Enter Student Name: ");
		name= s.nextLine();
		jd.update(tname, usn, name);
		}
		
		else if(ch==4) {
			Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter Table Name: ");
		tname= sc1.nextLine();
		System.out.println("Enter USN: ");
		usn= sc1.nextLine();
		jd.delete(tname, usn);
		}
		else
			System.out.println("Invalid Choice");
	}

	}
}
