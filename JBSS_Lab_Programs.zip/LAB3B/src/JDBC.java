import java.sql.*;
import java.util.Scanner;

import com.mysql.cj.exceptions.DataTruncationException;

class myException extends Exception{
	public String message="";
	myException(String myException){
		System.out.println(myException);
	}
}


public class JDBC {
	String tname,usn,name,address;
	Connection con = null;
	
	
public Connection getconnect()
{
	try
	{
	Class.forName("com.mysql.cj.jdbc.Driver");
	con = DriverManager.getConnection("jdbc:mysql://172.16.34.105:3306/1rv21mc083","1rv21mc083","1rv21mc083");
	}
	catch(SQLException e)
	{
		System.out.println(e);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	return con;
}

public void insert(String tname, String usn, String name, String address){
	try
	{
		con = getconnect();
		PreparedStatement ps = con.prepareStatement("insert into "+tname+" values('"+usn+"','"+name+"','"+address+"')");
		ps.executeUpdate("insert into "+tname+" values('"+usn+"','"+name+"','"+address+"')");
	}
	catch(DataTruncationException e)
	{
		System.out.println("Data is too long");
	}
	catch(SQLException e)
	{
		System.out.println(e);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	finally
	{
		try {
			con.close();
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}


public void display(String tname)
{
	
	try
	{
	con = getconnect();
	PreparedStatement ps = con.prepareStatement("select * from "+tname);
	ResultSet rs = ps.executeQuery("select * from "+tname);
	System.out.println("\n   USN        NAME       ADDRESS\n");
	while(rs.next())
	{
		System.out.println(rs.getString(1)+"   "+rs.getString(2)+"   "+rs.getString(3));
	}
	}
	catch(SQLException e)
	{
		System.out.println(e);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	finally
	{
		try {
			con.close();
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}


public void update(String tname,String usn, String name) {
	try
	{
		con = getconnect();
		PreparedStatement ps = con.prepareStatement("update "+tname+" set name='"+name+"' where usn='"+usn+"'");
		ps.executeUpdate("update "+tname+" set name='"+name+"' where usn='"+usn+"'");
	}
	catch(SQLException e)
	{
		System.out.println(e);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	finally
	{
		try {
			con.close();
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

public void delete(String tname, String usn) {
	try
	{
		con = getconnect();
		PreparedStatement ps = con.prepareStatement("delete from "+tname+" where usn='"+usn+"'");
		ps.executeUpdate("delete from "+tname+" where usn='"+usn+"'");
	}
	catch(SQLException e)
	{
		System.out.println(e);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	finally
	{
		try {
			con.close();
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}


public static void main(String[] args) throws Exception,SQLException {
	String tname,usn,name,address;
	JDBC jd = new JDBC();
	Scanner sc = new Scanner(System.in);
	
	while(true)
	{
		System.out.println("\n 0. Exit \n 1. Insert \n 2. Display \n 3. Update Name \n 4. Delete \n Enter Your Choice: ");
		int ch = sc.nextInt();
	
		if (ch==0) {
			System.exit(0);
		}
		
		else if(ch==2)	{
			try {
				Scanner s = new Scanner(System.in);
			System.out.println("Enter Table Name: ");
			tname = s.nextLine();
			
			if(tname.equalsIgnoreCase(""))
			{
				throw new myException("Table Name is Empty, Please Enter a Table Name");
			}
			jd.display(tname);
		}
			catch(myException e)
			{
				System.out.println(e.message);
			}
		}
	
		else if(ch==1) {
				try
				{
					Scanner ss = new Scanner(System.in);
					System.out.println("Enter Table Name: ");
					tname = ss.nextLine();
					System.out.println("Enter USN: ");
					usn = ss.nextLine();
					System.out.println("Enter Student Name: ");
					name = ss.nextLine();
					System.out.println("Enter Address: ");
					address = ss.nextLine();
					
					if(tname.equalsIgnoreCase("") || usn.equalsIgnoreCase("") || name.equalsIgnoreCase("") || address.equalsIgnoreCase(""))
					{
						throw new myException("Please enter all the fields");
					}
					jd.insert(tname, usn, name, address);
				}
				catch(myException e)
				{
					System.out.println(e.message);
				}
		
		}
	
		else if(ch==3) {
			try
			{
				Scanner s1 = new Scanner(System.in);
				System.out.println("Enter Table Name: ");
				tname = s1.nextLine();
				System.out.println("Enter USN: ");
				usn = s1.nextLine();
				System.out.println("Enter Name to be updated: ");
				name = s1.nextLine();
				
				if(tname.equalsIgnoreCase("") || usn.equalsIgnoreCase("") || name.equalsIgnoreCase(""))
				{
					throw new myException("Please enter all the fields");
				}
				jd.update(tname,usn,name);
			}
			catch(myException e)
			{
				System.out.println(e.message);
			}
		
		}
	
		else if(ch==4) {
			try
			{
				Scanner s = new Scanner(System.in);
				System.out.println("Enter Table Name: ");
				tname = s.nextLine();
				System.out.println("Enter USN: ");
				usn = s.nextLine();
				
				if(tname.equalsIgnoreCase("") || usn.equalsIgnoreCase(""))
				{
					throw new myException("Please enter all the fields");
				}
				jd.delete(tname, usn);
			}
			catch(myException e)
			{
				System.out.println(e.message);
			}
		}
		else
		System.out.println("Invalid Choice");
		}

	}

}
