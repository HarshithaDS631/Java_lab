package LAB41;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LSB41")
public class LSB41 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
  
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
    	
    	response.setIntHeader("Refresh", 1);
    	
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    	Date date = new Date();
    	PrintWriter out = response.getWriter();
    	out.println("Current Date and Time: "+sdf.format(date));
    	out.println("\n  Stock             Price");
    	out.println("\nPhone Pe    : "+100*Math.random());
    	out.println("\nGenpact     : "+100*Math.random());
    	out.println("\nBlue Yonder : "+100*Math.random());
    }
}
