package LAB2;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		String name=null,address=null,phno=null,email=null,company=null,empid=null,designation=null,usn = null,branch=null;
		float salary=0,fee=0;
		
		Scanner scc =new Scanner(System.in);
		while(true) {
			System.out.println("\n 0. Exit \n 1. Input Data \n 2. Display data \n\n Enter Your Choice ");
			int ch = scc.nextInt();
			if (ch==0)
				System.exit(0);
			else if (ch==1) {
				Scanner sc =new Scanner(System.in);
				System.out.println("\nEnter Name:");
				name = sc.nextLine();
				System.out.println("Enter Address:");
				address = sc.nextLine();
				System.out.println("Enter Phone Number:");
				phno = sc.nextLine();
				System.out.println("Enter Email-ID:");
				email = sc.nextLine();
				System.out.println("\nAre you a Staff ? then Enter 1 \nAre you a Student ? then Enter 2");
				int ch1 = sc.nextInt();
				if(ch1==1) {
					Scanner s1 =new Scanner(System.in);
					System.out.println("\nEnter Company:");
					company = s1.nextLine();
					System.out.println("Enter Employee ID:");
					empid = s1.nextLine();
					System.out.println("Enter Designation: (Manager/HR/Salesman)");
					designation = s1.nextLine();
					
					Staff_Op staff = new Staff(name,address,phno,email,company,empid,designation);
					salary=staff.salary(designation);
				}
				else if (ch1==2) {
					Scanner s =new Scanner(System.in);
					System.out.println("Enter USN:");
					usn = s.nextLine();
					System.out.println("Enter Branch:");
					branch = s.nextLine();
					Student_Op student = new Student(name,address,phno,email,usn,branch);
					fee=student.calculate_fee(branch);
				}
				else
					System.out.println("Invalid Choice");
			}
			else if(ch==2) {
				Scanner sc =new Scanner(System.in);
				System.out.println("\n1. Display Staff Details \n 2. Display Student Details \n\n Enter Your Choice");
				int ch2 = sc.nextInt();
				if (ch2==1) {
					Staff_Op staff = new Staff(name,address,phno,email,company,empid,designation);
					staff.display();
					System.out.println("Salary: "+salary);
				}
				else if(ch2==2) {
					Student_Op student = new Student(name,address,phno,email,usn,branch);
					student.display();
					System.out.println("Fee: "+fee);
					}
				else
					System.out.println("Invalid Choice");
			}
			else
				System.out.println("Invalid Choice");
		}
	}

}
