package LAB2;

public class Person {

	String name,address,phno,email;
	Person(String name, String address,String phno,String email){
		this.name=name;
		this.address=address;
		this.phno=phno;
		this.email=email;
		
	}
}
