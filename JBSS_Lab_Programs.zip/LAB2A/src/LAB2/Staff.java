package LAB2;

public class Staff extends Person implements Staff_Op{

	String company,empid,designation;
	Staff(String name, String address, String phno, String email,String company,String empid,String designation) {
		super(name, address, phno, email);
		this.company=company;
		this.empid=empid;
		this.designation=designation;
	}

	@Override
	public float salary(String designation) {
		if(this.designation.equalsIgnoreCase("MANAGER"))
			return Staff_Op.manager_salary;
		else if(this.designation.equalsIgnoreCase("HR"))
			return Staff_Op.hr_salary;
		else if(this.designation.equalsIgnoreCase("SALESMAN"))
			return Staff_Op.salesman_salary;
		
		return Staff_Op.default_salary;
	}

	@Override
	public void display() {
		System.out.println("Name: "+this.name);	
		System.out.println("Address: "+this.address);
		System.out.println("Phone Number: "+this.phno);
		System.out.println("Email-ID: "+this.email);
		System.out.println("Comapny: "+this.company);
		System.out.println("Employee ID: "+this.empid);
		System.out.println("Designation: "+this.designation);
		
		
	}

}
