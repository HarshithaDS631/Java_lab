package LAB2;

public interface Staff_Op {

	final float manager_salary=50000;
	final float hr_salary=30000;
	final float salesman_salary=20000;
	final float default_salary = 10000;
	public float salary(String designation);
	void display();
}
