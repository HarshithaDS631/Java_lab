package LAB2;

public interface Student_Op {

	final float mca_fee=50000;
	final float mtech_fee=80000;
	final float default_fee=20000;
	public float calculate_fee(String branch);
	void display();
}
