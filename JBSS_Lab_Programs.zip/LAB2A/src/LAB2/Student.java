package LAB2;

public class Student extends Person implements Student_Op {

	String usn,branch;
	Student(String name, String address, String phno, String email,String usn,String branch) {
		super(name, address, phno, email);
		this.usn=usn;
		this.branch=branch;
		}
	@Override
	public float calculate_fee(String branch) {
		if(this.branch.equalsIgnoreCase("MCA"))
			return Student_Op.mca_fee;
		else if(this.branch.equalsIgnoreCase("MTECH"))
			return Student_Op.mtech_fee;
		
		return Student_Op.default_fee;
	}
	
	@Override
	public void display() {
	System.out.println("Name: "+this.name);	
	System.out.println("Address: "+this.address);
	System.out.println("Phone Number: "+this.phno);
	System.out.println("Email-ID: "+this.email);
	System.out.println("USN: "+this.usn);
	System.out.println("Branch: "+this.branch);
		
	}

	


}
