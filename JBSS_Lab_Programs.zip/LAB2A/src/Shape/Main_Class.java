package Shape;
import Shape.Square;
import Shape.Triangle;
import Shape.Circle;
import java.util.Scanner;

public class Main_Class {

	public static void main(String[] args) {
		float side,base,height,radius;
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			
			System.out.println("\n0. Exit \n 1. Area of Square \n 2. Area of Triangle \n 3. Area of Circle \n\n Enter Your Choice: ");
			int ch = sc.nextInt();
			if (ch==0)
				System.exit(0);
			else if(ch==1) {
				System.out.println("Enter side of a Square: ");
				side= sc.nextFloat();
				Square sq = new Square();
				sq.area(side);
			}
			else if(ch==2) {
				System.out.println("Enter Base of a Triangle: ");
				base= sc.nextFloat();
				System.out.println("Enter Height of a Triangle: ");
				height= sc.nextFloat();
				Triangle t = new Triangle();				
				t.area(base, height);
			}
			else if(ch==3) {
				System.out.println("Enter Radius of a Circle: ");
				radius = sc.nextFloat();
				Circle c = new Circle();
				c.area(radius);
			}
			else
				System.out.println("Invalid Choice");

		}
	}
}
