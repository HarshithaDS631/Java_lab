package Shape;

public class Circle {

	void area(float radius) {
		System.out.println("Area of Circle: "+(Math.PI*radius*radius));
	}
}
