package Shape;

public class Triangle {

	void area(float base, float height) {
		System.out.println("Area of Triangle: "+(0.5*base*height));
	}
}
