package Shape;

public class Square {

	void area(float side) {
		System.out.println("Area of Square: "+(side*side));
}
}
